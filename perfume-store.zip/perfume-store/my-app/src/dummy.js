export const products = [
    { id: '1', name: 'Fragrance A', image: '/imageurls/imageurl-1.jpg', price: 50,quantity: 1 },
    { id: '2', name: 'Fragrance B', image: '/imageurls/imageurl-2.jpg', price: 70,quantity: 1 },
    { id: '3', name: 'Fragrance B', image: '/imageurls/imageurl-3.jpg', price: 70 ,quantity: 1},
    { id: '4', name: 'Fragrance B', image: '/imageurls/imageurl-4.jpg', price: 70,quantity: 1 },
  ]
  export const products1 = [
    { id: '5', name: 'Fragrance B', image: '/imageurls/imageurl-5.jpg', price: 70 ,quantity: 1},
    { id: '6', name: 'Fragrance B', image: '/imageurls/imageurl-6.jpg', price: 70,quantity: 1 },
    { id: '7', name: 'Fragrance B', image: '/imageurls/imageurl-7.jpg', price: 70 ,quantity: 1},
    { id: '8', name: 'Fragrance B', image: '/imageurls/imageurl-8.jpg', price: 70 ,quantity: 1},
    
  ];
  export const products2 = [
    { id: '9', name: 'Fragrance B', image: '/imageurls/imageurl-9.jpg', price: 70 ,quantity: 1},
    { id: '10', name: 'Fragrance B', image: '/imageurls/imageurl-10.jpg', price: 70 ,quantity: 1},
    { id: '11', name: 'Fragrance B', image: '/imageurls/imageurl-11.jpg', price: 70 ,quantity: 1},
    { id: '12', name: 'Fragrance B', image: '/imageurls/imageurl-12.jpg', price: 70,quantity: 1 },
  
  ];
  export const products3 = [
    { id: '13', name: 'Fragrance B', image: '/imageurls/imageurl-13.jpg', price: 70,quantity: 1 },
    { id: '14', name: 'Fragrance B', image: '/imageurls/imageurl-14.jpg', price: 70,quantity: 1 },
    { id: '15', name: 'Fragrance B', image: '/imageurls/imageurl-15.jpg', price: 70,quantity: 1 },
    { id: '16', name: 'Fragrance B', image: '/imageurls/imageurl-16.jpg', price: 70,quantity: 1 },
  
  ];
  export const products4 = [
    { id: '17', name: 'Fragrance B', image: '/imageurls/imageurl-17.jpg', price: 70 ,quantity: 1},
    { id: '18', name: 'Fragrance B', image: '/imageurls/imageurl-18.jpg', price: 70 ,quantity: 1},
    { id: '19', name: 'Fragrance B', image: '/imageurls/imageurl-19.jpg', price: 70 ,quantity: 1},
    { id: '20', name: 'Fragrance B', image: '/imageurls/imageurl-20.jpg', price: 70 ,quantity: 1},
   
  ];

  export const productsDescription = [
    { id: '1',  imageUrl: '/imageurls/imageurl-1.jpg',name: 'Rosy Cedar', price: 120, description: '.',quantity: 1 },
    { id: '2',  imageUrl: '/imageurls/imageurl-2.jpg',name: 'Floral Woods', price: 140, description: '.' ,quantity: 1},
    { id: '3',  imageUrl: '/imageurls/imageurl-3.jpg',name: 'Jasmine Breeze', price: 170, description: '.',quantity: 1 },
    { id: '4',  imageUrl: '/imageurls/imageurl-4.jpg',name: 'Woodland Pear', price: 290, description: '.' ,quantity: 1},
    { id: '5',  imageUrl: '/imageurls/imageurl-5.jpg',name: 'Citrus Bloom', price: 170, description: '.' ,quantity: 1},
    { id: '6',  imageUrl: '/imageurls/imageurl-6.jpg',name: 'Cedar Rose', price: 310, description: '.',quantity: 1 },
    { id: '7',  imageUrl: '/imageurls/imageurl-7.jpg',name: 'Mystic Petal', price: 270, description: '.' ,quantity: 1},
    { id: '8',  imageUrl: '/imageurls/imageurl-8.jpg',name: 'Fruity Essence', price: 210, description: '.',quantity: 1 },
    { id: '9',  imageUrl: '/imageurls/imageurl-9.jpg',name: 'Lavender Grove', price: 190, description: '.' ,quantity: 1},
    { id: '10',  imageUrl: '/imageurls/imageurl-10.jpg',name: 'Lilac & Moss', price: 300, description: '.',quantity: 1 },
    { id: '11',  imageUrl: '/imageurls/imageurl-11.jpg',name: 'Sandalwood Serenade', price: 180, description: '.',quantity: 1 },
    { id: '12',  imageUrl: '/imageurls/imageurl-12.jpg',name: 'Wildflower Dreams', price: 390, description: '.',quantity: 1 },
    { id: '13',  imageUrl: '/imageurls/imageurl-13.jpg',name: 'Peachy Magnolia', price: 370, description: '.' ,quantity: 1},
    { id: '14',  imageUrl: '/imageurls/imageurl-14.jpg',name: 'Wild Berry Woods', price: 200, description: '.',quantity: 1 },
    { id: '15',  imageUrl: '/imageurls/imageurl-15.jpg',name: 'Violet Mist', price: 460, description: '.',quantity: 1 },
    { id: '16',  imageUrl: '/imageurls/imageurl-16.jpg',name: 'Amber Blossom', price: 230, description: '.',quantity: 1 },
    { id: '17',  imageUrl: '/imageurls/imageurl-17.jpg',name: 'Forest Bouquet', price: 90, description: '.',quantity: 1 },
    { id: '18',  imageUrl: '/imageurls/imageurl-18.jpg',name: 'Sunset Orchard', price: 60, description: '.',quantity: 1 },
    { id: '19',  imageUrl: '/imageurls/imageurl-19.jpg',name: 'Orchid Breeze', price: 80, description: '.' ,quantity: 1},
    { id: '20',  imageUrl: '/imageurls/imageurl-20.jpg',name: 'Blossom Drift', price: 40, description: '.' ,quantity: 1},
    
  ];