import React from "react";
import "./App.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Home from "./pages/Home";
import ProductDetail from "./components/ProductDetail";
import Cart from "./components/Cart";
import Contact from "./pages/Contact";
import Checkout from "./components/Checkout";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

const App: React.FC = () => {
  const router = createBrowserRouter([
  
    {
      path: "/",
      element: <Home />,
    },
    {
      path: "/cart",
      element: <Cart />,
    },
    {
      path: "/productDetail/:id",
      element: <ProductDetail />,
    },

    {
      path: "/contact",
      element: <Contact />,
    },

    {
      path: "/checkout",
      element: <Checkout />,
    },
    {
      path: "/login",
      element: <Login/>,
    },
    {
      path: "/signup",
      element: <Signup/>,
    },
  ]);
  return (
      <RouterProvider router={router} />
  );
};

export default App;
