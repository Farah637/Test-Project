import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

const Signup: React.FC = () => {
  const [fullname, setFullname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();

    // Create a new user object
    const newUser = { fullname, email, password };

    // Retrieve existing users from local storage (if any)
    const existingUsers = localStorage.getItem("SignedupUsers");
    let usersArray = existingUsers ? JSON.parse(existingUsers) : [];

    // Add the new user to the array
    usersArray.push(newUser);

    // Store the updated array back in local storage
    localStorage.setItem("SignedupUsers", JSON.stringify(usersArray));

    // Navigate to the login page after signup
    navigate("/login");
  };

  return (
    <>
      <Navbar />
      <div className="signup">
        <h1>Sign Up</h1>

        <form onSubmit={handleSignup}>
          <input
            type="text"
            placeholder="Full Name"
            value={fullname}
            onChange={(e) => setFullname(e.target.value)}
          />
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit">Sign Up</button>
        </form>

        <p>
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </div>
      <Footer />
    </>
  );
};

export default Signup;
