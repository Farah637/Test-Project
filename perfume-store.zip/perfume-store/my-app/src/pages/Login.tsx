import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

const Login: React.FC = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const signedUpUsers = localStorage.getItem("SignedupUsers");
    if (signedUpUsers) {
      const usersArray = JSON.parse(signedUpUsers);
      const matchingUser = usersArray.find(
        (user: { email: string; password: string }) =>
          user.email === email && user.password === password
      );

      if (matchingUser) {
        localStorage.setItem("loggedInUser", JSON.stringify(matchingUser));
        navigate("/checkout");
      } else {
        alert("Invalid email or password. Please try again.");
      }
    } else {
      alert("No account found. Please sign up first.");
      navigate("/signup");
    }
  };

  return (
    <>
      <Navbar />
      <div className="Login-container">
        <h1>Login</h1>
        <form onSubmit={handleLogin}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit">Login</button>
        </form>

        <p>
          Don't have an account? <Link to="/signup">Sign up</Link>
        </p>
      </div>
      <Footer />
    </>
  );
};

export default Login;
