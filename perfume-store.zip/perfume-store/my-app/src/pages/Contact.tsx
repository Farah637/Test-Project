import React from 'react';
import Navbar from '../components/Navbar';
import Contactus from '../components/Contactus';
import Footer from '../components/Footer';



const Contact: React.FC = () => {
   
  return (
<>
<Navbar/>
<Contactus/>
<Footer/>
</>  
);
};

export default Contact;
