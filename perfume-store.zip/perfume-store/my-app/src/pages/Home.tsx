import React from 'react';
import Navbar from '../components/Navbar';
import GridComponent from '../components/GridComponent';
import Footer from '../components/Footer';

const Home: React.FC = () => {
   
  return (
<>
<Navbar/>
<GridComponent/>
<Footer/>
    

</>  
);
};

export default Home;
