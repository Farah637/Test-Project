import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";

import { productsDescription } from "../dummy";
const ProductDetail: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const product = productsDescription.find((p) => p.id === id);
  if (!product) {
    return <div>Product not found</div>;
  }
  const addToCart = () => {
    const cart = localStorage.getItem("Cart");
    let cartArray = [];
    if (cart) {
      cartArray = JSON.parse(cart);
    }
    cartArray.push(product);
    localStorage.setItem("Cart", JSON.stringify(cartArray));
  };
  const handleAddToCartAndNavigate = () => {
    addToCart(); // Call your addToCart function here
    navigate("/cart"); // Navigate to the cart page
  };

  return (
    <>
      <Navbar />

      <div className="product-detail-container">
      
        <button onClick={handleAddToCartAndNavigate} className="add-to-cart-button">Add to Cart</button>
        
        <p className="product-price">${product.price.toFixed(2)}</p>
        <p className="product-description">{product.description}</p>
        <h1 className="product-name">{product.name}</h1>
        <div className="product-image">
          <img src={product.imageUrl} alt={product.name} />
        </div>
        <div className="product-details">
          <p className="product-description">{product.description}</p>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default ProductDetail;
