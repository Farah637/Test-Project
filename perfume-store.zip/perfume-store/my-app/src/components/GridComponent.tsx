import React from 'react';
import { Link } from 'react-router-dom';

import {products} from '../dummy';
import {products1} from '../dummy';
import {products2} from '../dummy';
import {products3} from '../dummy';
import {products4} from '../dummy';

const GridComponent: React.FC = () => {
  return (
    <> <h1>New Arrival</h1>
    <div className="grid-container2">
      {products.map((product) => (
        <div key={product.id} className="grid-item2">
          <Link to={`/productDetail/${product.id}`}>
            <img src={product.image} alt={product.name} />
          </Link>
        </div>
      ))}
    </div>
    
    <div className="grid-container">
      {products1.map((products1) => (
        <div key={products1.id} className="grid-item">
          <Link to={`/productDetail/${products1.id}`}>
            <img src={products1.image} alt={products1.name} />
            <h3>{products1.name}</h3>
            <p>Price: ${products1.price}</p>
          </Link>
        </div>
      ))}
    </div>
    <h1>Best Sellers</h1>
    <div className="grid-container3">
      {products2.map((products2) => (
        <div key={products2.id} className="grid-item3">
          <Link to={`/productDetail/${products2.id}`}>
            <img src={products2.image} alt={products2.name} />
            <h3>{products2.name}</h3>
            <p>Price: ${products2.price}</p>
          </Link>
        </div>
      ))}
    </div>
    <div className="grid-container3">
    {products3.map((products3) => (
        <div key={products3.id} className="grid-item3">
          <Link to={`/productDetail/${products3.id}`}>
            <img src={products3.image} alt={products3.name} />
            <h3>{products3.name}</h3>
            <p>Price: ${products3.price}</p>
          </Link>
        </div>
      ))}
    </div>
    <h1>Scent deals</h1>
    <div className="grid-container3">
    {products4.map((products4) => (
        <div key={products4.id} className="grid-item3">
          <Link to={`/productDetail/${products4.id}`}>
            <img src={products4.image} alt={products4.name} />
            <h3>{products4.name}</h3>
            <p>Price: ${products4.price}</p>
          </Link>
        </div>
      ))}
    </div>
   
    </>
  );
};

export default GridComponent;
