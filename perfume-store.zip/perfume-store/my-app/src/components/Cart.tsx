import React, { useEffect, useState } from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { Link } from "react-router-dom";
import { useNavigate } from 'react-router-dom';


const Cart: React.FC = () => {
  const [cart, setCart] = useState<any[]>([]);
  const navigate = useNavigate();

  const handleProceedToCheckout = () => {
    const user = localStorage.getItem('loggedInUser');
    if (user) {
      // If user is logged in, navigate to checkout
      navigate('/checkout');
    } else {
      // If user is not logged in, navigate to login
      navigate('/login');
    }
  };


  // Fetch cart from localStorage on component mount
  useEffect(() => {
    const storedCart = localStorage.getItem("Cart");
    if (storedCart) {
      console.log(JSON.parse(storedCart));
      setCart(JSON.parse(storedCart));
    }
  }, []);

  // Remove item from cart
  const removeFromCart = (id: number) => {
    const updatedCart = cart.filter((item) => item.id !== id);
    setCart(updatedCart);
    localStorage.setItem("Cart", JSON.stringify(updatedCart));
  };

  return (
    <>
      <Navbar />
      <div className="cart-container">
        <h2>Your Cart</h2>
        <table>
          <thead>
            <tr>
              <th>Product</th>
              <th>Name</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {cart.length > 0 ? (
              cart.map((item) => (
                <tr key={item.id}>
                  <td>
                    <img src={item.imageUrl} alt={item.name} width="50" />
                  </td>
                  <td>{item.name}</td>
                  <td>${item.price.toFixed(2)}</td>
                  <td>{item.quantity}</td>
                  <td>
                    <button
                      className="delete-btn"
                      onClick={() => removeFromCart(item.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={4}>Your cart is empty</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {cart.length > 0 && (
      
          <button className="proceed-button" onClick={handleProceedToCheckout}>Proceed to Checkout</button>
       
      )}
      <Footer />
    </>
  );
};

export default Cart;
