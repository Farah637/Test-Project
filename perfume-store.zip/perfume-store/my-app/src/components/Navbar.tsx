import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Navbar: React.FC = () => {
  const navigate = useNavigate();
  const [userEmail, setUserEmail] = useState();

  const handleLogout = () => {
    localStorage.removeItem("loggedInUser");
    navigate("/login");
  };
  useEffect(() => {
    const storedUser = localStorage.getItem("loggedInUser");
    if (storedUser) {
      const user = JSON.parse(storedUser);
      setUserEmail(user?.email);
    }
  }, []);
  return (
    <nav className="navbar">
      <Link to="/" className="navbar-link">
        <h1 className="navbar-logo">My Perfume Store</h1>
      </Link>
      <h2 className="navbar-logo">{userEmail}</h2>
      <ul className="nav-links">
        <li>
          <Link to="/" className="nav-item">
            Home
          </Link>
        </li>
        <li>
          <Link to="/Contact" className="nav-item">
            Contact
          </Link>
        </li>
        <li>
          <Link to="/Cart" className="nav-item">
            Cart
          </Link>
        </li>
        {/* <li>
          <button onClick={handleLogout} className="logout-button">
            Logout
          </button>
        </li> */}
        <li></li>
      </ul>
    </nav>
  );
};

export default Navbar;
