import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <p>&copy; {new Date().getFullYear()} Your Company. All rights reserved.</p>
        <ul className="footer-links">
          <Link to="/contact"><li><a href="#privacy">Privacy Policy</a></li></Link>
          <Link to="/contact"><li><a href="#terms">Terms of Service</a></li></Link>
          <Link to="/contact"><li><a href="#contact">Contact Us</a></li></Link>
        </ul>
      </div>
    </footer>
  );
};

export default Footer;
