import React, { useState, useEffect } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';


const Checkout: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    paymentMethod: 'creditCard',
  });
  const [cart, setCart] = useState<any[]>([]);
  const [totalCost, setTotalCost] = useState(0);

  useEffect(() => {
    const storedCart = localStorage.getItem('Cart');
    if (storedCart) {
      const parsedCart = JSON.parse(storedCart);
      setCart(parsedCart);

      // Calculate total cost
      const total = parsedCart.reduce((acc: number, item: any) => acc + item.price * item.quantity, 0);
      setTotalCost(total);
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleCheckout = () => {
    alert('Order placed');
  };

  return (
    <>
      <Navbar />
      <div className="checkout-page">
        <h1>Checkout</h1>

        <div className="checkout-summary">
          <h2>Order Summary</h2>
          <ul>
            {cart.length > 0 ? (
              cart.map((item) => (
                <li key={item.id}>
                  {item.name} x {item.quantity}: ${item.price * item.quantity}
                </li>
              ))
            ) : (
              <li>Your cart is empty</li>
            )}
          </ul>
          <h3>Total: ${totalCost.toFixed(2)}</h3>
        </div>

        <div className="shipping-form">
          <h2>Shipping Information</h2>
          <input
            type="text"
            name="name"
            placeholder="Full Name"
            value={formData.name}
            onChange={handleInputChange}
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleInputChange}
          />
          <input
            type="text"
            name="address"
            placeholder="Shipping Address"
            value={formData.address}
            onChange={handleInputChange}
          />
        </div>

        <div className="payment-method">
          <h2>Payment Method</h2>
          <select
            name="paymentMethod"
            value={formData.paymentMethod}
            onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
          >
            <option value="creditCard">Credit Card</option>
            <option value="paypal">PayPal</option>
          </select>
        </div>

        <button onClick={handleCheckout}>Place Order</button>
      </div>
      <Footer />
    </>
  );
};

export default Checkout;
