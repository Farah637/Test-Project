import React, { useState } from 'react';

const ContactUs: React.FC = () => {
  const [inputValue, setInputValue] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [message, setMessage] = useState<string>(''); 

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(event.target.value);
  };
  const handleEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(event.target.value);
  };
  const handleMessageChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(event.target.value);
  };
  const handleSubmit = () => {
    alert(`Form Submitted!\nName: ${inputValue}\nEmail: ${email}\nMessage: ${message}`);
  };

  return (
   <><div className='contact-us'>
          <h1>Contact Us</h1>
      </div>
     
     
      <div className="contact-us-container">
              <label htmlFor="nameInput" className="input-label">Name:</label>
              <input
                  id="nameInput"
                  type="text"
                  value={inputValue}
                  onChange={handleInputChange}
                  className="input-field"
                  placeholder="Enter your name" />
             <label htmlFor="nameInput" className="input-label">Email:</label>
              <input
                  id="nameInput"
                  type="text"
                  value={email}
                  onChange={handleEmailChange}
                  className="input-field"
                  />
             <label htmlFor="messageInput" className="input-label">Message:</label>
              <textarea
                id="messageInput"
                value={message}
                onChange={handleMessageChange}
                 className="textarea-field"
                 placeholder="Enter your message"
                   />
          </div>
          <button onClick={handleSubmit} className="submit-button">Send</button>
          <section className="faq-section">
        <h2>FAQs</h2>
        <div className="faq-item">
          <h3>How can I track my order?</h3>
          <p>You can track your order by visiting the order tracking page or by contacting us with your order number.</p>
        </div>
        <div className="faq-item">
         <h3>What is your return policy?</h3>
          <p>We accept returns within 30 days of purchase. Please visit our returns page for more information.</p>
        </div>
        <div className="faq-item">
         <h3>How long does it last?</h3>
          <p>Lasting varies for every perfume. The lasting duration of any fragrance depends on the application area, season, and quantity applied.</p>  
        </div>
        
      </section>
          </> 
  );
};

export default ContactUs;
